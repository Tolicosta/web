jQuery(document).ready(function () {
    $("#login").submit(function (e) {
        e.preventDefault();

        $.post("Login/login", {email: $("#email").val(), senha: $("#senha").val()}, function (resultado) {
            
        });

        return false;
    });
});