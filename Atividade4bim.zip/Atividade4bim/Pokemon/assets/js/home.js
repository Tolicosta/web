jQuery(document).ready(function () {
    $("#remover").click(function() {
		var id = $(this).parent("td:eq(0)");
		$.post("Home/remover", {id: id.val()}, function(){
			location.reload();
		});
    });
});
