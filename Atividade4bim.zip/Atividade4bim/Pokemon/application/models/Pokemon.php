<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Pokemon extends CI_Model {
	
	public function __construct(){
        parent::__construct();
    }
	
    public function listar(){
        return $this->db->get("pokemon")->result_array();
    }
    
    public function inserir($nome, $data_Captura, $tipo_Pokemon){
		$vet = array(
			"nome" => $nome,
			"data_Captura" => $data_Captura,
			"tipo_Pokemon" => $tipo_Pokemon
		);
		
		$this->db->insert("pokemon", $vet);
	}

	public function remover($id){
		$this->db->where("id", $id);
		$this->db->where->delete("pokemon");
	}

}
