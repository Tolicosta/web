<!DOCTYPE html>
<html lang="pt">
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">

		<title>Pokémon Go</title>
		
		<link href="<?php echo base_url("assets/css/bootstrap.min.css"); ?>" rel="stylesheet">
        <link href="<?php echo base_url("assets/css/estilo.css"); ?>" rel="stylesheet">
	</head>

	<body>
		<nav class="navbar navbar-inverse navbar-fixed-top">
			
			<div class="container">
				
				<div class="navbar-header">
					<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
					<span class="sr-only">Toggle navigation</span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					</button>
					<a class="navbar-brand" href="#">Pokemón Go</a>
				</div>
				
			</div>
			
		</nav>

		<div class="container">

			<div class="starter-template">
				<table class="table table-hover">
					<thead>
						<tr>
							<th>Id</th>
							<th>Nome</th>
							<th>Data de Captura</th>
							<th>Tipo do Pokémon</th>
														
							<th>Editar</th>
							<th>Remover</th>
						</tr>
					</thead>
					
					<tbody>
						{pokemon}
						<tr>
							<td>{id}</td>
							<td>{nome}</td>
							<td>{data_Captura}</td>
							<td>{tipo_Pokemon}</td>
							
							<td>
								<button type="button" class="btn btn-info">
									<span class="glyphicon glyphicon-pencil">
									
									</span>
								</button>
							</td>
							
							<td>
								<button type="button" class="btn btn-danger remover">
									<span class="glyphicon glyphicon-trash">
									
									</span>
								</button>
							</td>
						</tr>
						
						
						{/pokemon}
					</tbody>
				</table>
				
				<button type="button" class="btn btn-success btn-block" data-toggle="modal" data-target="#inserirModal">
					<span class="glyphicon glyphicon-plus">
									
					</span> Adicionar
				</button>
				
			</div>

		</div>
	</body>
	
	<script src="<?php echo base_url("assets/js/jquery.min.js") ?>"></script>
    <script src="<?php echo base_url("assets/js/bootstrap.min.js") ?>"></script>
    <script src="<?php echo base_url("assets/js/home.js") ?>"></script>
</html>


<div class="modal fade" tabindex="-1" role="dialog" id="inserirModal">
	<div class="modal-dialog" role="document">
		
		<div class="modal-content">
			
			<div class="modal-header">
				<button type="button" class="fechar" data-dismiss="modal" aria-label="Fechar"><span aria-hidden="true">&times;</span></button>
				<h4 class="modal-title">Adicionar</h4>
			</div>
			
			<div class="modal-body">
				<form method="POST" action="Home/inserir" id="inserir">
					<div class="form-group">
						<label for="nome">Nome</label>
						<input type="text" class="form-control" id="nome" Placeholder="Nome">
					</div>
					
					<div class="form-group">
						<label for="data_Captura">Data de Captura</label>
						<input type="text" class="form-control" id="data_Captura" Placeholder="Data de Captura">
					</div>
					
					<div class="form-group">
						<select class="form-control" id="tipo">
							<option></option>
							<option value="Verde">Verde</option>
							<option value="Laranja">Laranja</option>
							<option value="Vermelho">Vermelho</option>
						</select>
					</div>
					<button type="submit" class="btn btn-primary btn-block">Salvar</button>
				</form>
			</div>
			
			<div class="modal-footer">
				
			</div>
			
		</div>
		
	</div>
	
</div>
