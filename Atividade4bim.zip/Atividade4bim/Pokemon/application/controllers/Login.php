<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends CI_Controller {

    public function __construct() {
        parent::__construct();
    }

    public function index() {
        $this->load->view("login");
    }

    public function login() {
        $email = $this->input->post()["email"];
        $senha = $this->input->post()["senha"];

        $this->load->model("Usuario");
        $usuario = $this->Usuario->get($email, $senha);

        $sessao["email"] = $usuario["email"];
        $sessao["logado"] = true;

        $this->session->set_userdata($sessao);

        redirect(base_url("Home"));

        echo json_encode($usuario);
    }

}
