<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller {

    public function index() {
        if ($this->session->has_userdata("logado")) {
			$this->load->model("Pokemon");
			$lista = $this->Pokemon->listar();
			
			$vetor = array(
				"pokemon" => $lista
			);
			
			$this->parser->parse("home", $vetor);
        }
        else {
            redirect(base_url("Login"));
        }
    }
    
    public function inserir(){
		$this->load->model("Pokemon");
		
		$nome = $this->input->post()["nome"];
		$data_Captura = $this->input->post()["data_Captura"];
		$tipo_Pokemon = $this->input->post()["tipo_Pokemon"];
		
		$this->Pokemon->inserir($nome, $data_Captura, $tipo_Pokemon);
	}
	
	public function remover(){
		$id = $this->input->post()["id"];
		
		$this->load->model("Pokemon");
		$this->Pokemon->remover($id);
	}

}
